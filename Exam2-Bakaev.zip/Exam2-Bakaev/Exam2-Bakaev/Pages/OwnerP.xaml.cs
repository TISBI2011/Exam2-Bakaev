﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exam2_Bakaev.Pages
{
    /// <summary>
    /// Логика взаимодействия для OwnerP.xaml
    /// </summary>
    public partial class OwnerP : Page
    {
        public OwnerP()
        {
            InitializeComponent();
            MenuListDG.ItemsSource = App.DB.Menu.ToList();
        }

        private void AddBT_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddP());
        }

        private void DropBT_Click(object sender, RoutedEventArgs e)
        {
            var selectedEmployee = MenuListDG.SelectedItem as Menu;
            if (selectedEmployee != null)
            {
                App.DB.Menu.Remove(selectedDish);
                App.DB.SaveChanges();
                MessageBox.Show("Succes");
            }
            else MessageBox.Show("select something");
            MenuListDG.ItemsSource = App.DB.users.ToList();

        }

        private void EditBT_Click(object sender, RoutedEventArgs e)
        {
            var selectedEmployee = MenuListDG.SelectedItem as Menu;
            if (selectedEmployee != null)
            {
                NavigationService.Navigate(new EditP(selectedDish));
            }
            else MessageBox.Show("select something");
        }
    }
}
