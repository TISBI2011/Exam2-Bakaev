﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exam2_Bakaev.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddP.xaml
    /// </summary>
    public partial class AddP : Page
    {
        Menu context;
        public AddP()
        {
            InitializeComponent();
            MenuListDG.ItemsSource = App.DB.Dish.ToList();
            context = new Menu();
            DataContext = context;
        }

        private void AddBT_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var tryRegUser = App.DB.Menu.Where(a => a.DishName == context.DishName);
                if (tryRegUser.Any())
                {
                    MessageBox.Show("Это блюдо уже в меню");
                    return;
                }
                else
                {
                    var SelectedDish = AddBT.SelectedItem as DishName;
                    context.IDdish = SelectedDish.id;
                    App.DB.Menu.Add(context);
                    App.DB.SaveChanges();
                    MessageBox.Show("succes");
                    NavigationService.Navigate(new OwnerP());

                }
            }
            catch
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void BackBT_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OwnerP());
        }
    }
}
