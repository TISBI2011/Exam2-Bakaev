﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exam2_Bakaev.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginP.xaml
    /// </summary>
    public partial class LoginP : Page
    {
        public LoginP()
        {
            InitializeComponent();
            context = new Employees();
            DataContext = context;

        }

        private void LogInBT_Click(object sender, RoutedEventArgs e)
        {
            var tryLoggedUser = App.DB.Employees.Where(a => a.login == context.login && a.password == context);
            if(tryLoggedUser.Any())
            {
                App.LoggedUser = tryLoggedUser.First();
                if (App.LoggedUser.IDPost == 1) NavigationService.Navigate(new OwnerP());
                if (App.LoggedUser.IDPost == 2) NavigationService.Navigate(new HRManagerP());
                if (App.LoggedUser.IDPost == 3) NavigationService.Navigate(new CookP());
            }
            else
            {
                MessageBox.Show("Аккаунта не существует");
            }
        }
    }
}
